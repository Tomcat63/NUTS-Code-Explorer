# SPDX-FileCopyrightText: 2024 Jonathan Sejdija
#
# SPDX-License-Identifier: AGPL-3.0-or-later
from .main import get_nuts, get_region_by_prefix, convert_plz_to_nuts